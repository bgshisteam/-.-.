﻿param(
  [string]$EhpIcon = "$env:LOCALAPPDATA\EHPIcons\ehp.ico",
  [string]$SsoIcon = "$env:LOCALAPPDATA\EHPIcons\sso.ico"
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

function SafeName([string]$n){
  $n = $n -replace '[<>:"/\\|?*]',' '
  $n = $n.Trim().TrimEnd('.')    # ห้ามลงท้ายด้วยจุด
  return $n
}

$links = @(
  @{ Name = SafeName "แพลตฟอร์มกลาง รพ.สต"; Url = "https://pcu-uat.moph.go.th/ehp/";                  Icon = $EhpIcon },
  @{ Name = SafeName "Login SSO";               Url = "https://sso-uat.moph.go.th/admin/login"; Icon = $SsoIcon }
)

$desktops = @(
  "$env:USERPROFILE\Desktop",
  "$env:OneDrive\Desktop",
  "$env:OneDrive\เดสก์ท็อป",
  "$env:USERPROFILE\เดสก์ท็อป",
  [Environment]::GetFolderPath("Desktop")
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

$ws = New-Object -ComObject WScript.Shell
$explorer = Join-Path $env:WINDIR "explorer.exe"

foreach($d in $desktops){
  foreach($l in $links){
    $lnk = Join-Path $d ($l.Name + ".lnk")
    $url = Join-Path $d ($l.Name + ".url")
    if (Test-Path -LiteralPath $url) { Remove-Item -LiteralPath $url -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $lnk) { Remove-Item -LiteralPath $lnk -Force -ErrorAction SilentlyContinue }

    $iconSpec = $null
    if (Test-Path -LiteralPath $l.Icon) { $iconSpec = "$($l.Icon),0" }

    $sc = $ws.CreateShortcut($lnk)
    $sc.TargetPath       = $explorer
    $sc.Arguments        = $l.Url
    $sc.WorkingDirectory = $env:WINDIR
    if ($iconSpec) { $sc.IconLocation = $iconSpec }   # ต้องมี ,0
    $sc.Description = $l.Url
    $sc.Save()

    # ย้ำให้ Explorer โหลดใหม่: เปลี่ยนเวลาแก้ไขไฟล์
    (Get-Item -LiteralPath $lnk).LastWriteTime = Get-Date
    Write-Host "✓ Created: $lnk (Icon: $iconSpec)"
  }
}
